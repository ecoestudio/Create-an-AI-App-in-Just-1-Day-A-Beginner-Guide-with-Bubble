import ecpay_payment from 'ecpay_aio_nodejs'; 
 
const MERCHANTID = "2000132"; // 綠界金流測試特店編號 
const HASHKEY = "5294y06JbISpM5x9"; // 綠界金流測試特店HASHKEY金鑰 
const HASHIV = "v77hoKGq4kWxNNIS"; // 綠界金流測試特店HASHIV金鑰 
const HOST = " https://AWSURL"; //讀者的AWS URL 
 
const options = { 
  OperationMode: 'Test', //Test or Production 
  MercProfile: { 
    MerchantID: MERCHANTID, 
    HashKey: HASHKEY, 
    HashIV: HASHIV, 
  }, 
  IgnorePayment: [ 
  ], 
  IsProjectContractor: false, 
}; 
 
export const handler = async (event) => { 
    const MerchantTradeDate = new Date().toLocaleString('zh-TW', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit',
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit', 
      hour12: false, 
      timeZone: 'UTC', 
    }); 
 
    let base_param = { 
      MerchantTradeNo: event.payment_id, 
      MerchantTradeDate, 
      TotalAmount: event.NTD, 
      TradeDesc: event.TradeDesc, 
      ItemName: `點數儲值${event.point}點`, 
      ReturnURL: `${HOST}/return`,  //或是讀者的 Bubble back-end API endpoint 
      ClientBackURL: `${HOST}/clientReturn` 
    }; 
 
    const create = new ecpay_payment(options); 
    const html = create.payment_client.aio_check_out_all(base_param); 
 
    const response = { 
      statusCode: 200, 
      headers: { 'Content-Type': 'text/html' }, 
      body: html, 
    }; 
     
    return response; 
  }; 