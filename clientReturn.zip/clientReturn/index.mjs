export const handler = async (event) => { 
  const response = { 
    statusCode: 302,  // 302 表示重導向 
    headers: { 
      "Location": "https://domainname.com",  //讀者需自行設定希望的導向頁面 
    }, 
  }; 
 
  return response; 
}; 