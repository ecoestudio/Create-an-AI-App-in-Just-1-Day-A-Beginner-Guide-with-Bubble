import fetch from 'node-fetch'; 
import ecpay_payment from 'ecpay_aio_nodejs'; 
import querystring from 'querystring'; 
 
const MERCHANTID = "2000132"; // 綠界金流測試特店編號 
const HASHKEY = "5294y06JbISpM5x9"; // 綠界金流測試特店HASHKEY金鑰 
const HASHIV = "v77hoKGq4kWxNNIS"; // 綠界金流測試特店HASHIV金鑰 
 
const options = { 
  OperationMode: 'Test', //Test or Production 
  MercProfile: { 
    MerchantID: MERCHANTID, 
    HashKey: HASHKEY, 
    HashIV: HASHIV, 
  }, 
  IgnorePayment: [], 
  IsProjectContractor: false, 
}; 
 
export const handler = async (event) => { 
   
  const decodedBody = Buffer.from(event.body, 'base64').toString('utf-8'); 解碼綠界伺服器端的請求 
  const body = querystring.parse(decodedBody); 
   
  const { CheckMacValue, MerchantTradeNo } = body; 
  const data = { ...body }; 
  delete data.CheckMacValue; 
   
  const create = new ecpay_payment(options); 
  const checkValue = create.payment_client.helper.gen_chk_mac_value(data); 
  const isValid = CheckMacValue === checkValue; 
 
  //以會員儲值功能為例，若isValid，讀者可於此自行撰寫Bubble DB API，進行DB相關操作以增加點數 
 
  return { 
      statusCode: 200, 
      body: isValid? '1|OK':'0|NO', //若成功 
      headers: { 
          'Content-Type': 'text/plain', 
      }, 
  }; 
}; 