import fetch from 'node-fetch';
import ecpay_payment from 'ecpay_aio_nodejs';
import querystring from 'querystring';

const MERCHANTID = "2000132";
const HASHKEY = "5294y06JbISpM5x9";
const HASHIV = "v77hoKGq4kWxNNIS";

const options = {
  OperationMode: 'Test',
  MercProfile: {
    MerchantID: MERCHANTID,
    HashKey: HASHKEY,
    HashIV: HASHIV,
  },
  IgnorePayment: [],
  IsProjectContractor: false,
};

export const handler = async (event) => {
  
  const decodedBody = Buffer.from(event.body, 'base64').toString('utf-8');
  const body = querystring.parse(decodedBody);
  console.log('Parsed body:', body);
  
  const { CheckMacValue, MerchantTradeNo } = body;
  const data = { ...body };
  delete data.CheckMacValue;
  
  const create = new ecpay_payment(options);
  const checkValue = create.payment_client.helper.gen_chk_mac_value(data);
  const isValid = CheckMacValue === checkValue;

  return {
      statusCode: 200,
      body: isValid? '1|OK':'0|NO',
      headers: {
          'Content-Type': 'text/plain',
      },
  };
};
